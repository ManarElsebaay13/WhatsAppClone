package com.example.manarelsebaay.scopechat;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.os.Bundle;


public class MainActivity extends AppCompatActivity {

    private Toolbar mtoolbar ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mtoolbar=(findViewById(R.id.main_toolbar));

        setSupportActionBar(mtoolbar);
        getSupportActionBar().setTitle("ScopeChat");
    }
}
